# editing the Eric Quotes website

This site is intentionally organized around a small set of files. You can update the content without touching the layout, and you can add new views without rewriting the data layer.

## adding or changing quote entries

Edit `client/public/data/quotes.json`. Live quotes belong under `quotes`; preserved entries belong under `archive`. Every entry should include `name`, `author`, `context`, and `description`. Live quote keys should be ISO timestamps because the interface uses them to display the original date. Archive keys become the archive label and the readable part of the detail URL.

Edit `client/public/data/qotd.txt` to choose the Quote of the Day. The value must exactly match a live quote's `name` field. The QOTD page searches that file, finds the matching JSON record, and renders its other fields automatically.

Edit `client/public/data/README.md` when the repository story or its links change. The small renderer in `client/src/App.tsx` supports headings, paragraphs, bold text, inline code, and markdown links. Relative links are converted to their matching GitHub repository URLs so the README always points back to the source items.

## adding a new page

Create a component in `client/src/App.tsx` or move the page components into `client/src/pages/` if the project gets larger. Add a `Route` inside the `Switch` near the bottom of the file. Keep the global `<SiteHeader />` and `<footer>` in `App`; this gives every new page the same navigation and escape route.

For new data-driven pages, use `useQuoteData()` rather than fetching JSON again. The normalized `QuoteRecord` type is the single contract between source files and the interface. If you add new JSON fields, add them to that type and show them with the reusable `Field` component.

## adding a reusable function

Put a short JSDoc comment immediately above every new function. Explain what the function does, what input shape it expects, and what part of the site calls it. Prefer pure functions for parsing and formatting. Keep visual behavior in components and CSS. This makes the codebase easy to scan and keeps new features from becoming tangled.

## fonts and logo

The supplied fonts live in `client/public/fonts/` and are loaded in `client/src/index.css`. Axera Round is used for titles and interface labels; J Audio Cassette is used for body copy. The logo is an inline SVG in `LogoMark`, so its paths can be edited directly without an image generator or an external asset pipeline.

## local development

Run `npm install`, then `npm run dev`. Run `npm run check` for TypeScript validation and `npm run build` for a production build. The Vite preview supports the client-side routes used by the app.

## GitHub Pages deployment

The requested hosting workflow is at `scripts/host-website.yml`. Copy it to `.github/workflows/host-website.yml` in the repository that contains this website. By default it expects this project at the repository root and uses pnpm. If you keep it in a subfolder, change `WEBSITE_DIR` and the artifact path to match.

The workflow uses GitHub Pages' official build and deploy actions. In the repository settings, set **Pages → Build and deployment → Source** to **GitHub Actions** once. After that, pushes to `main` rebuild and publish the site.
