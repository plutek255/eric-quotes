## "IT'S NOT MY BIRTHDAY!"

**Author:** Eric

**Context:** Eric's friends have an inside joke since last year where they started saying 'happy birthday', because someone told one of the teachers and they proceeded to say 'Happy birthday, Eric!' over the loudspeaker.

**Description:** The team now has a running joke that Eric's birthday is year-round, and Eric embraces it, though he used to hate being told 'happy birthday' every single day.
