import { useEffect, useMemo, useState } from "react";
import type { ReactElement } from "react";
import { Link, Route, Router, Switch, useLocation, useRoute } from "wouter";
import { ArrowLeft, ArrowUpRight, BookOpen, ChevronDown, Clock3, Quote, Search } from "lucide-react";
import "./index.css";

/**
 * A normalized record keeps the UI independent from the shape of quotes.json.
 * Add new display fields here when the source data grows; the page components
 * only consume this small, stable interface.
 */
type QuoteRecord = {
  id: string;
  collection: "quotes" | "archive";
  name: string;
  author: string;
  context: string;
  description: string;
  date?: string;
  archiveLabel?: string;
};

type QuotePayload = {
  quotes?: Record<string, Omit<QuoteRecord, "id" | "collection">>;
  archive?: Record<string, Omit<QuoteRecord, "id" | "collection">>;
};

/**
 * Turns a title into a predictable URL key. The source key is preserved in
 * quote data, while slugs keep URLs readable and easy to bookmark.
 */
function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 72);
}

/**
 * Converts the repository's nested JSON into a flat list for cards, search,
 * the rotating hero stack, and detail routes.
 */
function normalizePayload(payload: QuotePayload): QuoteRecord[] {
  const live = Object.entries(payload.quotes ?? {}).map(([date, value], index) => ({
    id: `${slugify(value.name)}-${index}`,
    collection: "quotes" as const,
    date,
    name: value.name,
    author: value.author ?? "Unknown",
    context: value.context ?? "",
    description: value.description ?? "",
  }));
  const archive = Object.entries(payload.archive ?? {}).map(([key, value]) => ({
    id: slugify(key),
    collection: "archive" as const,
    archiveLabel: key,
    name: value.name,
    author: value.author ?? "Unknown",
    context: value.context ?? "",
    description: value.description ?? "",
  }));
  return [...live, ...archive];
}

/**
 * Small markdown renderer for the repository README. It intentionally handles
 * the README's documented subset instead of shipping a large markdown parser,
 * keeping this site easy to edit and dependency-light.
 */
function renderReadme(source: string): ReactElement[] {
  const inline = (value: string, key: string) => {
    const parts = value.split(/(\[[^\]]+\]\([^\)]+\)|\*\*[^*]+\*\*)/g);
    return parts.map((part, index) => {
      const link = part.match(/^\[([^\]]+)\]\(([^\)]+)\)$/);
      if (link) {
        const [, label, href] = link;
        const finalHref = href.startsWith("http")
          ? href
          : `https://github.com/plutek255/eric-quotes/blob/main/${href.replace(/^\.\//, "")}`;
        return (
          <a key={`${key}-link-${index}`} href={finalHref} target="_blank" rel="noreferrer">
            {label} <ArrowUpRight size={13} aria-hidden="true" />
          </a>
        );
      }
      const bold = part.match(/^\*\*(.+)\*\*$/);
      return bold ? <strong key={`${key}-strong-${index}`}>{bold[1]}</strong> : part;
    });
  };

  return source.split(/\n/).map((line, index) => {
    const key = `readme-${index}`;
    if (!line.trim()) return <div className="readme-gap" key={key} />;
    if (line.startsWith("# ")) return <h2 key={key}>{inline(line.slice(2), key)}</h2>;
    if (line.startsWith("## ")) return <h3 key={key}>{inline(line.slice(3), key)}</h3>;
    const list = line.match(/^`([^`]+)`\s+-\s+(.+)$/);
    if (list) {
      return (
        <div className="readme-list-item" key={key}>
          <code>{list[1]}</code><span>{inline(list[2], key)}</span>
        </div>
      );
    }
    return <p key={key}>{inline(line, key)}</p>;
  });
}

/**
 * The global header stays hidden while the landing hero is at its top edge,
 * then fades in after the visitor scrolls so the first screen stays editorial.
 */
function SiteHeader() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 42 || location !== "/");
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [location]);

  return (
    <header className={`site-header ${scrolled ? "site-header-visible" : ""}`}>
      <Link href="/" className="brand" aria-label="Eric Quotes home">
        <LogoMark size={34} />
        <span>Eric Quotes</span>
      </Link>
      <nav aria-label="main navigation">
        <Link href="/qotd">Quote of the Day</Link>
        <Link href="/library">Quote Library</Link>
      </nav>
    </header>
  );
}

/** The hand-built mark is intentionally inline SVG so it stays editable. */
function LogoMark({ size = 50 }: { size?: number }) {
  return (
    <svg className="logo-mark" width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="Eric Quotes logo">
      <path id="logo-path" d="M22 50 C22 28 34 17 50 17 C67 17 78 29 78 50 C78 71 67 83 50 83 C34 83 22 71 22 50 Z" fill="none" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
      <path d="M38 43 H62 M38 56 H58" fill="none" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
      <circle cx="50" cy="50" r="4" fill="currentColor" />
    </svg>
  );
}

/**
 * A compact loader that traces a very short logo route. As progress advances,
 * the loop speeds up and the outline fills, matching the requested behavior.
 */
function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const started = performance.now();
    const tick = (now: number) => {
      const next = Math.min(1, (now - started) / 850);
      setProgress(next);
      if (next < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, []);
  const speed = Math.max(0.16, 1.7 * (1 - progress));
  return (
    <div className="loading-screen" aria-label="Loading Eric Quotes" role="status">
      <div className="loader-logo">
        <svg viewBox="0 0 100 100" aria-hidden="true">
          <path className="loader-track" d="M22 50 C22 28 34 17 50 17 C67 17 78 29 78 50 C78 71 67 83 50 83 C34 83 22 71 22 50 Z" />
          <path className="loader-progress" d="M22 50 C22 28 34 17 50 17 C67 17 78 29 78 50 C78 71 67 83 50 83 C34 83 22 71 22 50 Z" style={{ strokeDashoffset: `${157 - progress * 157}px` }} />
          <circle r="4" fill="var(--ink)">
            <animateMotion dur={`${speed}s`} repeatCount="indefinite" rotate="auto" path="M22 50 C22 28 34 17 50 17 C67 17 78 29 78 50 C78 71 67 83 50 83 C34 83 22 71 22 50 Z" />
          </circle>
        </svg>
      </div>
      <span>opening the archive</span>
    </div>
  );
}

/** Handles fetching the editable public data bundle once for the whole app. */
function useQuoteData() {
  const [records, setRecords] = useState<QuoteRecord[]>([]);
  const [readme, setReadme] = useState("");
  const [qotdName, setQotdName] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const dataUrl = (file: string) => `${import.meta.env.BASE_URL}data/${file}`;
    Promise.all([
      fetch(dataUrl("quotes.json")).then((response) => response.json()),
      fetch(dataUrl("README.md")).then((response) => response.text()),
      fetch(dataUrl("qotd.txt")).then((response) => response.text()),
    ]).then(([payload, readmeText, qotdText]) => {
      setRecords(normalizePayload(payload));
      setReadme(readmeText);
      setQotdName(qotdText.trim());
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);
  return { records, readme, qotdName, loading };
}

/** The landing page keeps the hero quiet and gives the README the spotlight below. */
function HomePage({ records, readme }: { records: QuoteRecord[]; readme: string }) {
  const liveQuotes = records.filter((record) => record.collection === "quotes");
  return (
    <>
      <section className="hero" id="home">
        <div className="hero-copy">
          <p className="eyebrow">a living collection / est. 2026</p>
          <h1>Eric<br /><span>Quotes</span></h1>
          <p className="hero-intro">A tirelessly maintained archive of the things Eric says, remembers, and accidentally makes legendary.</p>
          <a className="text-link" href="#readme">read the story <ArrowDownIcon /></a>
        </div>
        <div className="stack-stage" aria-label="Rotating stack of quotes">
          <div className="stack-caption"><span>01</span><span>from the archive</span></div>
          <div className="quote-stack">
            {liveQuotes.slice(0, 3).map((quote, index) => (
              <article className={`stack-card stack-card-${index}`} key={quote.id}>
                <div className="card-no">0{index + 1}</div>
                <Quote size={21} strokeWidth={1.5} aria-hidden="true" />
                <p className="stack-quote-text">“{quote.name}”</p>
                <span>— {quote.author}</span>
              </article>
            ))}
          </div>
          <div className="stack-orbit" aria-hidden="true" />
        </div>
        <div className="scroll-note"><span className="scroll-line" />scroll to explore</div>
      </section>
      <section className="readme-section" id="readme">
        <div className="section-kicker"><span>01</span><span>the readme</span></div>
        <div className="readme-layout">
          <div className="readme-title"><p className="eyebrow">direct from the repository</p><h2>The story<br /><em>behind</em> the quotes.</h2></div>
          <div className="readme-content">{renderReadme(readme)}</div>
        </div>
      </section>
    </>
  );
}

/** Quote of the Day resolves qotd.txt against the normalized JSON records. */
function QotdPage({ records, qotdName }: { records: QuoteRecord[]; qotdName: string }) {
  const quote = records.find((record) => record.collection === "quotes" && record.name.trim() === qotdName.trim()) ?? records.find((record) => record.collection === "quotes");
  if (!quote) return <EmptyState />;
  return (
    <main className="page-shell qotd-page">
      <div className="section-kicker"><span>today's selection</span><span>{new Date().toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" })}</span></div>
      <div className="qotd-layout">
        <div className="qotd-label"><span className="qotd-dot" /> quote of the day</div>
        <article className="qotd-card">
          <div className="card-no">selected from quotes.json</div>
          <Quote size={42} strokeWidth={1.2} aria-hidden="true" />
          <h1>“{quote.name}”</h1>
          <div className="qotd-meta"><span>— {quote.author}</span><span>{quote.date ? new Date(quote.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : "from the archive"}</span></div>
          {quote.context && <p className="context-note">{quote.context}</p>}
        </article>
      </div>
    </main>
  );
}

/** The library is searchable, filterable, and uses one card pattern for both collections. */
function LibraryPage({ records }: { records: QuoteRecord[] }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "quotes" | "archive">("all");
  const visible = useMemo(() => records.filter((record) => {
    const matchesFilter = filter === "all" || record.collection === filter;
    const haystack = `${record.name} ${record.context} ${record.description}`.toLowerCase();
    return matchesFilter && haystack.includes(search.toLowerCase());
  }), [records, search, filter]);
  return (
    <main className="page-shell library-page">
      <div className="section-kicker"><span>02 / browse everything</span><span>{records.length} entries</span></div>
      <div className="library-heading"><div><p className="eyebrow">the complete collection</p><h1>Quote<br /><em>Library</em></h1></div><p>Every live quote and preserved archive entry, indexed from the repository data.</p></div>
      <div className="library-toolbar">
        <label className="search-box"><Search size={17} aria-hidden="true" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="search the archive" aria-label="search quotes" /></label>
        <div className="filter-set" role="group" aria-label="filter quote collection">
          {(["all", "quotes", "archive"] as const).map((value) => <button key={value} className={filter === value ? "active" : ""} onClick={() => setFilter(value)}>{value === "all" ? "all entries" : value}</button>)}
        </div>
      </div>
      <div className="library-grid">
        {visible.map((record, index) => <QuoteCard record={record} index={index} key={`${record.collection}-${record.id}`} />)}
      </div>
      {!visible.length && <div className="empty-results"><Search size={24} /><p>nothing matched that search.</p></div>}
    </main>
  );
}

/** A reusable card links to a detail route, making new records automatically visible. */
function QuoteCard({ record, index }: { record: QuoteRecord; index: number }) {
  return (
    <Link href={`/quote/${record.collection}/${record.id}`} className="quote-card">
      <div className="quote-card-top"><span className="card-no">{String(index + 1).padStart(2, "0")}</span>{record.collection === "archive" ? <span className="archive-tag"><i className="fa-solid fa-box-archive" aria-hidden="true" /> Archive</span> : <span className="live-tag">Live quote</span>}</div>
      <h2>“{record.name}”</h2>
      <p>{record.description === "No description" ? record.context : record.description}</p>
      <div className="quote-card-footer"><span>— {record.author}</span><ArrowUpRight size={17} /></div>
    </Link>
  );
}

/** Displays any normalized quote with all available JSON fields formatted as sections. */
function DetailPage({ records }: { records: QuoteRecord[] }) {
  const [, params] = useRoute("/quote/:collection/:id");
  const record = records.find((item) => item.collection === params?.collection && item.id === params?.id);
  if (!record) return <EmptyState />;
  return (
    <main className="page-shell detail-page">
      <Link href="/library" className="back-link"><ArrowLeft size={16} /> back to library</Link>
      <div className="detail-grid">
        <div className="detail-aside"><span className="detail-index">{record.collection === "archive" ? "archived entry" : "live entry"}</span><span className="vertical-rule" /><span className="detail-index">{record.author}</span></div>
        <article className="detail-card">
          <div className="quote-card-top"><span className="card-no">{record.collection === "archive" ? record.archiveLabel : record.date}</span>{record.collection === "archive" && <span className="archive-tag"><i className="fa-solid fa-box-archive" aria-hidden="true" /> Archive</span>}</div>
          <Quote size={36} strokeWidth={1.2} aria-hidden="true" />
          <h1>“{record.name}”</h1>
          <div className="detail-fields">
            <Field label="author" value={record.author} />
            {record.date && <Field label="date" value={new Date(record.date).toLocaleString("en-US", { dateStyle: "long", timeStyle: "short" })} />}
            <Field label="context" value={record.context} />
            <Field label="description" value={record.description} />
          </div>
        </article>
      </div>
    </main>
  );
}

/** Renders a label/value pair so adding more JSON properties stays easy. */
function Field({ label, value }: { label: string; value: string }) {
  return <div className="detail-field"><span>{label}</span><p>{value || "Not recorded."}</p></div>;
}

function ArrowDownIcon() { return <ChevronDown size={17} aria-hidden="true" />; }
function EmptyState() { return <main className="page-shell empty-state"><BookOpen size={32} /><h1>That page is still being catalogued.</h1><Link href="/library">return to the library</Link></main>; }

/** App-level routing and one shared data request keep every page consistent. */
export default function App() {
  const { records, readme, qotdName, loading } = useQuoteData();
  const [ready, setReady] = useState(false);
  useEffect(() => { if (!loading) setTimeout(() => setReady(true), 120); }, [loading]);
  if (!ready) return <LoadingScreen />;
  const configuredBase = import.meta.env.BASE_URL;
  const routerBase = configuredBase === "./" ? "" : configuredBase.replace(/\/$/, "");
  return (
    <div className="app-shell">
      <SiteHeader />
      <Router base={routerBase}>
        <Switch>
          <Route path="/"><HomePage records={records} readme={readme} /></Route>
          <Route path="/qotd"><QotdPage records={records} qotdName={qotdName} /></Route>
          <Route path="/library"><LibraryPage records={records} /></Route>
          <Route path="/quote/:collection/:id"><DetailPage records={records} /></Route>
          <Route><EmptyState /></Route>
        </Switch>
      </Router>
      <footer className="site-footer"><Link href="/">Eric Quotes</Link><span>an archive of human nonsense</span><span>built for the record</span></footer>
    </div>
  );
}
