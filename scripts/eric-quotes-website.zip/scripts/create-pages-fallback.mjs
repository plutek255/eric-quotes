import fs from "node:fs";
import path from "node:path";

const publicDir = path.resolve("dist/public");
const indexPath = path.join(publicDir, "index.html");
const fallbackPath = path.join(publicDir, "404.html");
const repositoryBase = "/eric-quotes/";

const indexHtml = fs.readFileSync(indexPath, "utf8");
const redirectScript = `<script>
(function () {
  var base = ${JSON.stringify(repositoryBase)};
  var pathname = window.location.pathname;
  if (pathname.indexOf(base) === 0) {
    var route = pathname.slice(base.length).replace(/^\\/+|\\/+$/g, "");
    if (route && route !== "index.html") {
      window.location.replace(base + "#/" + route + window.location.search);
    }
  }
})();
</script>`;

fs.writeFileSync(fallbackPath, indexHtml.replace("</head>", `${redirectScript}</head>`));
console.log(`created ${fallbackPath}`);
