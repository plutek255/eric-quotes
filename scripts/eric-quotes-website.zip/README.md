# Eric Quotes website

A handmade editorial archive for the Eric Quotes repository. It uses the supplied Axera Round and J Audio Cassette fonts, a small inline SVG logo, a paper-and-ink palette, and a restrained motion system.

## included pages

- `/` — the landing hero and repository README, with relative links resolved to the real GitHub items
- `/qotd` — the Quote of the Day from `client/public/data/qotd.txt`
- `/library` — searchable live and archive cards
- `/quote/:collection/:id` — formatted JSON detail pages for every card

## quick start

```bash
pnpm install
pnpm dev
```

For a production check:

```bash
pnpm check
pnpm build
```

The main editing guide is in [EDITING.md](EDITING.md). The requested GitHub Pages workflow is in [scripts/host-website.yml](scripts/host-website.yml).

## source data

The site reads these files at runtime from `client/public/data/`:

- `quotes.json` for live and archived records
- `qotd.txt` for the exact Quote of the Day name match
- `README.md` for the homepage's repository story

The UI normalizes those records once in `client/src/App.tsx`, so adding a new JSON entry automatically adds it to the library, search, detail page, and any relevant homepage selection.
